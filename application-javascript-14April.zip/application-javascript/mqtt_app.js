

var nw = require('./Abstracted_mymodules_location.js');


async function Create_fun(payload){
	
	let res = await nw.CreateAsset(payload);
	console.log("inside create() " , res);
	
	let p =JSON.stringify(res, null, 2);
	 await new Promise(resolve => setTimeout(resolve, 3000)); // 3 sec
	 client.publish(topic3, p, { qos: 0, retain: false }, (error) => {
				   
	})
}

async function Read_fun()
{
	let res = await nw.GetAllAssets();

	 let PublishPayload = { "TransactionType" : "MyAssets" , "Data" : JSON.parse(res)}
	 console.log("data published : " , PublishPayload);
	 let p =JSON.stringify(PublishPayload, null, 2);
	 await new Promise(resolve => setTimeout(resolve, 3000)); // 3 sec
	 client.publish(topic2, p, { qos: 0, retain: false }, (error) => {
				   
	})
	console.log("data published : " , PublishPayload);

	
}

async function Transfer_fun(payload){



	let res = await nw.TransferAssets(payload);
	console.log("inside Transfer() " , res);
	
	let p =JSON.stringify(res, null, 2);
	 await new Promise(resolve => setTimeout(resolve, 3000)); // 3 sec
	 client.publish(topic2, p, { qos: 0, retain: false }, (error) => {
				   
	})
}

async function Update_fun(payload){

	let res = await nw.UpdateAssets(payload);
	console.log("inside Update() " , res);
	
	let p =JSON.stringify(res, null, 2);
	 await new Promise(resolve => setTimeout(resolve, 3000)); // 3 sec
	 client.publish(topic2, p, { qos: 0, retain: false }, (error) => {
				   
	})
}


async function GetHistory_fun(payload){

	let res = await nw.GetHistory(payload.AssetId);

	let PublishPayload = { "TransactionType" : "History" , "Data" : JSON.parse(res)}
    
	let p =JSON.stringify(PublishPayload, null, 2);
	await new Promise(resolve => setTimeout(resolve, 3000)); // 3 sec
	client.publish(topic2, p, { qos: 0, retain: false }, (error) => {
				   
	})
	console.log("data published : " , PublishPayload);
}

let obj_copy={"data":"hello"}
let count=1
let client =1
var topic = 'ClientToNetwork';
var topic2 = 'NetworkToClientOrg1';
var topic3 = 'NetworkToClientOrg2';
async function main(){

		//Making Connection with Network

		const resp = await nw.CreateNetworkConnection();
		console.log('\n');
		console.log('Connection Respond : ' , resp);
		console.log('\n');



		client = await nw.CreateMqttConnection();
		client.on('connect', () => {
			console.log(`Client is Connected to MQTT`)
			client.subscribe([topic ], () => {
			  console.log(`Client has subscribed to the topic : ` , topic)
			})
	
		  })

		  client.on('reconnect', (error) => {
			console.log(`Reconnectin:`, error)
		  })
		  
		  client.on('error', (error) => {
			console.log(`Cannot connect :`, error)
		  })
		  
		  client.on('message', (topic, payload) => {
			console.log('Recieved Message from:', topic, payload.toString())
			
			var obj = JSON.parse(payload)
            

            if (obj.Status=="Yes" && count==2)
            {
                
                Create_fun(obj_copy);
				console.log("data created in the network payload is",payload.toString())
            }
			if (obj.Status=="No" && count==2)
            {
                
				client.publish(topic2, payload, { qos: 0, retain: false }, (error) => {
				   
                })
				console.log("data creation not approved and updated to organization,payload is",payload.toString())
            }
            if (obj.Status=="Yes" && count==3)
            {
                
                Transfer_fun(obj_copy);
				console.log("data transfered in the network payload is",payload.toString())
            }
			if (obj.Status=="No" && count==3)
            {
                
				client.publish(topic2, payload, { qos: 0, retain: false }, (error) => {
				   
                })
				console.log("data transfer not approved and updated to organization,payload is",payload.toString())
            }
			if (obj.Status=="Yes" && count==4)
            {
                Update_fun(obj_copy);
                //Read_fun();
				console.log("data updated in the network payload is",payload.toString())
            }
			if (obj.Status=="No" && count==4)
            {
                
				client.publish(topic2, payload, { qos: 0, retain: false }, (error) => {
				   
                })
				console.log("data update not approved and updated to organization,payload is",payload.toString())
            }



			
			if (obj.TransactionType == "Create")
            {
                
                client.publish(topic3, payload, { qos: 0, retain: false }, (error) => {
				   
                })

                
                console.log("data created and waiting for destination approval")
		      
                obj_copy =JSON.parse(payload)
                count=2
            

			}







            if (obj.TransactionType == "Transfer")
            {
                
                // client.publish(topic3, payload, { qos: 0, retain: false }, (error) => {
				   
                // })

                
                // console.log("data transfered and waiting for destination approval")
		      
                // obj_copy =JSON.parse(payload)
               
                // count=3

				Transfer_fun(obj);
				console.log("data transfered in the network payload is",payload.toString())
            

			}



			if (obj.TransactionType == "Update")
            {
                
                // client.publish(topic3, payload, { qos: 0, retain: false }, (error) => {
				   
                // })

                
                // console.log("data updated and waiting for destination approval")
		      
                // obj_copy =JSON.parse(payload)
              
                // count=4
				Update_fun(obj);
                //Read_fun();
				console.log("data updated in the network payload is",payload.toString())
            

			}

			

			if (obj.TransactionType == "History"){

				GetHistory_fun(obj);
			}

			if (obj.TransactionType == "Read"){

				Read_fun();
			}
		
	
		})
		  
		  


}

main();

