const { Gateway, Wallets } = require('fabric-network');
const FabricCAServices = require('fabric-ca-client');
const path = require('path');
const { buildCAClient, registerAndEnrollUser, enrollAdmin } = require('../../test-application/javascript/CAUtil.js');
const { buildCCPOrg1, buildWallet } = require('../../test-application/javascript/AppUtil.js');

const channelName = 'mychannel';
const chaincodeName = 'basic';
const mspOrg1 = 'Org1MSP';
const walletPath = path.join(__dirname, 'wallet');
const org1UserId = 'appUser';

function prettyJSONString(inputString) {
	return JSON.stringify(JSON.parse(inputString), null, 2);
}


//Connecting to Network
async function  NetworkConnection (){
	
	try {
		// build an in memory object with the network configuration (also known as a connection profile)
		const ccp = buildCCPOrg1();

		// build an instance of the fabric ca services client based on
		// the information in the network configuration
		const caClient = buildCAClient(FabricCAServices, ccp, 'ca.org1.example.com');

		// setup the wallet to hold the credentials of the application user
		const wallet = await buildWallet(Wallets, walletPath);

		// in a real application this would be done on an administrative flow, and only once
		await enrollAdmin(caClient, wallet, mspOrg1);

		// in a real application this would be done only when a new user was required to be added
		// and would be part of an administrative flow
		await registerAndEnrollUser(caClient, wallet, mspOrg1, org1UserId, 'org1.department1');

		// Create a new gateway instance for interacting with the fabric network.
		// In a real application this would be done as the backend server session is setup for
		// a user that has been verified.
		const gateway = new Gateway();

		try {
			// setup the gateway instance
			// The user will now be able to create connections to the fabric network and be able to
			// submit transactions and query. All transactions submitted by this gateway will be
			// signed by this user using the credentials stored in the wallet.
			await gateway.connect(ccp, {
				wallet,
				identity: org1UserId,
				discovery: { enabled: true, asLocalhost: true } // using asLocalhost as this gateway is using a fabric network deployed locally
			});

			// Build a network instance based on the channel where the smart contract is deployed
			const network = await gateway.getNetwork(channelName);

			// Get the contract from the network.
			const contract = network.getContract(chaincodeName);
		

			return contract;

			// let result = await contract.evaluateTransaction('GetAllAssets');
			// console.log(`*** Result: ${prettyJSONString(result.toString())}`);

		}
		catch (error) {
			console.error(`******** Not able to connect: ${error}`);
		}
			
		} catch (error) {
		console.error(`******** FAILED to run the application: ${error}`);
	}
			
			
	
}

//Contract Instance Object use for executing transaction
let contract = null



exports.CreateNetworkConnection = async function (){

	try{
		contract = await NetworkConnection();   // Updating Contract Instance
		return "Sucessful";
	}
	catch (error) {
		console.error(`Error While Connecting: ${error}`);
		return "error";
	}



}

exports.InitializeAsset = async function (){
	//const contract  = await NetworkConnection();

	console.log('\n--> Submit Transaction: InitLedger, function creates the initial set of assets on the ledger');
	await contract.submitTransaction('InitLedger');
	console.log('*** Result: committed')

}



exports.GetAllAssets = async function (){

	//const contract  = await NetworkConnection();
	try{
			console.log('\n--> Evaluate Transaction: GetAllAssets, function returns all the current assets on the ledger');
			let result = await contract.evaluateTransaction('GetAllAssets');
			console.log(`*** Result: ${prettyJSONString(result.toString())}`);
			return prettyJSONString(result.toString());
			//return prettyJSONString(result);
	}
	catch (error) {
		console.error(`******** get all asset error : ${error}`);

		
		return "error";
	}

}


exports.CreateAsset = async function (payload){
			//const contract  = await NetworkConnection()
			AssetId = payload.AssetId;
			//AssetId = Data.now();
			AssetName = payload.AssetName;
			Quantity = payload.Quantity;
			AssetOwner = payload.Owner;
			Price = payload.Price;
			location = payload.location;
			food_quality = payload.FoodQuality;
	
			console.log('\n--> Submit Transaction: CreateAsset, creates new asset with ID, color, owner, size, and appraisedValue arguments');
			result = await contract.submitTransaction('CreateAsset', AssetId, AssetName, Quantity, AssetOwner, Price , location , food_quality);
			console.log('*** Asset Created Successfully: committed');
			if (`${result}` !== '') {
				console.log(`*** Result: ${prettyJSONString(result.toString())}`);
			}
}

exports.TransferAssets = async function (payload){

			AssetId = payload.AssetId;
			NewOwnerName = payload.NewOwnerName;
			location = payload.location;
			food_quality = payload.FoodQuality;
			
			console.log('\n--> Submit Transaction: TransferAsset');
			await contract.submitTransaction('TransferAsset', AssetId, NewOwnerName, location  ,food_quality);
			console.log('*** Result: committed');
}

exports.UpdateAssets = async function (payload){

	AssetId = payload.AssetId;
	AssetName = payload.AssetName;
	Quantity = payload.Quantity;
	AssetOwner = payload.Owner;
	Price = payload.Price;
	location = payload.location;
	food_quality = payload.FoodQuality;

	console.log('\n--> Submit Transaction: UpdateAsset asset1, change the appraisedValue to 350');
	await contract.submitTransaction('UpdateAsset', AssetId , AssetName , Quantity , AssetOwner, Price, location ,food_quality);
	console.log('*** Result: committed');
}



exports.GetHistory= async function (AssetId){

	console.log('\n--> Submit Transaction: Get Asset History');
	result = await contract.evaluateTransaction('GetAssetsHistory', AssetId);
	//console.log(`*** Result: ${result.toString('utf-8')}`);
	console.log(`*** Result: ${prettyJSONString(result.toString('utf-8'))}`);

	return prettyJSONString(result.toString('utf-8'));

}



const mqtt = require('mqtt')
const fs = require('fs')
const { Command } = require('commander')



exports.CreateMqttConnection = async function(){
			const program = new Command()
			program
			.option('-p, --protocol <type>', 'connect protocol: mqtt, mqtts, ws, wss. default is mqtt', 'mqtt')
			.parse(process.argv)

			const host = 'broker.emqx.io'
			const port = '1883'
			const clientId = `mqtt_${Math.random().toString(16).slice(3)}`

			// connect options
			const OPTIONS = {
			clientId,
			clean: true,
			connectTimeout: 4000,
			username: 'emqx',
			password: 'public',
			reconnectPeriod: 1000,
			}
			// protocol list
			const PROTOCOLS = ['mqtt', 'mqtts', 'ws', 'wss']

			// default is mqtt, unencrypted tcp connection
			let connectUrl = `mqtt://${host}:${port}`
			if (program.protocol && PROTOCOLS.indexOf(program.protocol) === -1) {
			console.log('protocol must one of mqtt, mqtts, ws, wss.')
			} else if (program.protocol === 'mqtts') {
			// mqttsï¼ encrypted tcp connection
			connectUrl = `mqtts://${host}:8883`
			OPTIONS['ca'] = fs.readFileSync('./broker.emqx.io-ca.crt')
			} else if (program.protocol === 'ws') {
			// ws, unencrypted WebSocket connection
			const mountPath = '/mqtt' // mount path, connect emqx via WebSocket
			connectUrl = `ws://${host}:8083${mountPath}`
			} else if (program.protocol === 'wss') {
			// wss, encrypted WebSocket connection
			const mountPath = '/mqtt' // mount path, connect emqx via WebSocket
			connectUrl = `wss://${host}:8084${mountPath}`
			OPTIONS['ca'] = fs.readFileSync('./broker.emqx.io-ca.crt')
			} else {}

			const topic = 'hlf_mqtt'

			const client = mqtt.connect(connectUrl, OPTIONS)

			return client;
}

