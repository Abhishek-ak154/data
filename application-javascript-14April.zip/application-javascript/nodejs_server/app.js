const http = require('http');
var qs = require('querystring');


const requestListener = (request, res)=>{
console.log("Request is Incoming");


if (request.method == 'POST') {
        var body = '';

        request.on('data', function (data) {
            console.log(data.toString());
			body = data.toString();

            // Too much POST data, kill the connection!
            // 1e6 === 1 * Math.pow(10, 6) === 1 * 1000000 ~~~ 1MB
    		const responseData = {
	
				Incoming_Data:{
					data : JSON.parse(body)
				}
	
			}
				
			console.log(responseData);
			const jsonContent = JSON.stringify(responseData);
			res.end(jsonContent);
        });


    }




//console.log('p_data' , p_data);



};

const server = http.createServer(requestListener);

server.listen(3000,'localhost', function(){
	console.log("Server is Listening at Port 3000!");
});

