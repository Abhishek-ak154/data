var http = require('http');



const data = JSON.stringify({
    todo: 'Buy the milk'
  })

  
var option = {
    hostname : "localhost" ,
    port : 3000 ,
    method : "GET",
    path : "/"
} 

    var request = http.request(option , function(resp){
       resp.on("data",function(chunck){
           console.log(chunck.toString());
       }) 
    })
    request.write(data)
    request.end();
