const http = require('http');
var qs = require('querystring');



var nw = require('.././Abstracted_mymodules_location.js');

async function Create_fun(payload){
	
	await nw.CreateAsset(payload);
	
}

async function Read_fun(){
	 let res = await nw.GetAllAssets();

	 let PublishPayload = { "TransactionType" : "MyAssets" , "Data" : JSON.parse(res)}
	 
	 console.log("Inside Read_fun() : " , PublishPayload);
	
}

async function Transfer_fun(payload){

	await nw.TransferAssets(payload);
}

async function Update_fun(payload){

	await nw.UpdateAssets(payload);
}


async function GetHistory_fun(payload){

	let res = await nw.GetHistory(payload.AssetId);

	let PublishPayload = { "TransactionType" : "History" , "Data" : JSON.parse(res)}

	console.log("Inside History_fun() : " , PublishPayload);
}



async function post_main(obj){

	const resp = await nw.CreateNetworkConnection();
	console.log('\n');
	console.log('Connection Respond : ' , resp);
	console.log('\n');

	if (obj.TransactionType == "Create"){

		Create_fun(obj);
	}

	if (obj.TransactionType == "Transfer"){

		Transfer_fun(obj);
	}

	if (obj.TransactionType == "Update"){

		Update_fun(obj);
	}

	if (obj.TransactionType == "History"){

		//console.log(new Date().toLocaleString());
		GetHistory_fun(obj);
	}

	if (obj.TransactionType == "Read"){

		Read_fun(obj);
	}
	

}

async function read_main(obj){



}


const requestListener = (request, res)=>{
console.log("Request is Incoming");


if (request.method == 'POST') {
        var body = '';

        request.on('data', function (data) {
            //console.log(data.toString());
			body = data.toString();

			var json_obj = JSON.parse(body);

    		const responseData = { data : json_obj}
			post_main(json_obj);
			//console.log(json_obj.Mydata)
				
			console.log(responseData);
			const jsonContent = JSON.stringify(responseData);
			res.end(jsonContent);
        });


    }
if(request.method == 'GET'){

	const responseData = {
		data : "Data for get request"
	 }

	 
	console.log(responseData);
	const jsonContent = JSON.stringify(responseData);
	res.end(jsonContent);
}

};

const server = http.createServer(requestListener);

server.listen(3000,'localhost', function(){
	console.log("Server is Listening at Port 3000!");
});

