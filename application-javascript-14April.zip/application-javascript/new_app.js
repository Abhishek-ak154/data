



var nw = require('./Abstracted_mymodules_location.js');

async function Create_fun(payload){
	
	await nw.CreateAsset(payload);
	
}

async function Read_fun(){
	 let res = await nw.GetAllAssets();

	 let PublishPayload = { "TransactionType" : "MyAssets" , "Data" : JSON.parse(res)}
	 
	 console.log("Inside Read_fun() : " , PublishPayload);
	
}

async function Transfer_fun(payload){

	await nw.TransferAssets(payload);
}

async function Update_fun(payload){

	await nw.UpdateAssets(payload);
}


async function GetHistory_fun(payload){

	let res = await nw.GetHistory(payload.AssetId);

	let PublishPayload = { "TransactionType" : "History" , "Data" : JSON.parse(res)}

	console.log("Inside History_fun() : " , PublishPayload);
}




async function main(){

		//Making Connection with Network

		const resp = await nw.CreateNetworkConnection();
		console.log('\n');
		console.log('Connection Respond : ' , resp);
		console.log('\n');



		const client = await nw.CreateMqttConnection();



		//var topic = 'ClientToNetwork';
		var topic = 'hlf123';

		client.on('connect', () => {
			console.log(`Client is Connected to MQTT`)
			client.subscribe([topic ], () => {
			  console.log(`Client has subscribed to the topic : ` , topic)
			})
	
		  })

		  client.on('reconnect', (error) => {
			console.log(`Reconnectin:`, error)
		  })
		  
		  client.on('error', (error) => {
			console.log(`Cannot connect :`, error)
		  })
		  
		  client.on('message', (topic, payload) => {
			console.log('Transaction Info : ', topic, payload.toString())
			
			var obj = JSON.parse(payload)
			//console.log("transaction info : " , obj);
			if (obj.TransactionType == "Create"){

				Create_fun(obj);
			}

			if (obj.TransactionType == "Transfer"){

				Transfer_fun(obj);
			}

			if (obj.TransactionType == "Update"){

				Update_fun(obj);
			}

			if (obj.TransactionType == "History"){

				//console.log(new Date().toLocaleString());
				GetHistory_fun(obj);
			}

			if (obj.TransactionType == "Read"){

				Read_fun(obj);
			}
	
			
		})
		  
		  


}

main();

