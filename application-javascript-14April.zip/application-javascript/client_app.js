const https = require('http')

const data = JSON.stringify({
	"TransactionType" : "Create",
	"AssetId" : "12343151",
	"AssetName" : "apple",
  	"Quantity" : "1233",
	"Owner" : "abhishek",
  "NewOwnerName" : "Biswadeep",
	"Price" : "1200",
	"location" : "delhi",
	"FoodQuality" : "Fresh Apple"
})

//hostname: '20.44.58.43',
const options = {
  hostname: 'localhost',
  port: 3000,
  path: '/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
}

const req = https.request(options, res => {
  console.log(`statusCode: ${res.statusCode}`)


  res.on('data', d => {
    process.stdout.write(d)
    console.log();
  })
})

req.on('error', error => {
  console.error(error)
})

req.write(data)
req.end()

