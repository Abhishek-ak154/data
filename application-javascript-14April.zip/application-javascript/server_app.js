const http = require('http');
var qs = require('querystring');



var nw = require('./Abstracted_mymodules_location.js');

async function Create_fun(payload){
	
	await nw.CreateAsset(payload);
	
}

async function Read_fun(){
	 let res = await nw.GetAllAssets();

	 let PublishPayload = { "TransactionType" : "MyAssets" , "Data" : JSON.parse(res)}
	 
	 return PublishPayload;
	
}

async function Transfer_fun(payload){

	await nw.TransferAssets(payload);
}

async function Update_fun(payload){

	await nw.UpdateAssets(payload);
}


async function GetHistory_fun(payload){

	let res = await nw.GetHistory(payload.AssetId);

	let PublishPayload = { "TransactionType" : "History" , "Data" : JSON.parse(res)}

	console.log("Inside History_fun() : " , PublishPayload);

	return PublishPayload;
}



 async function post_main(obj , res){



	if (obj.TransactionType == "Create"){

		let result = await Create_fun(obj);

		res.end();
	}

	if (obj.TransactionType == "Transfer"){

		Transfer_fun(obj);
	}

	if (obj.TransactionType == "Update"){

		Update_fun(obj);
	}

	if (obj.TransactionType == "History"){

		//console.log(new Date().toLocaleString());
		let data =  await GetHistory_fun(obj);
		console.log('inside History fun' , data);
		const jsonContent = JSON.stringify(data);
		res.write(jsonContent);
		res.end();
	
	}

	if (obj.TransactionType == "Read"){

		let data = await Read_fun(obj);
		console.log('inside read fun' , data);
		const jsonContent = JSON.stringify(data);
		res.write(jsonContent);
		res.end();

	}
	

}

async function read_main(obj){



}


const requestListener = (request, res)=>{
console.log("Request is Incoming");

let jsonContent = {'dummy' : 'data'};
var json_obj;
if (request.method == 'POST') {
        var body = '';

        request.on('data', function (data) {
            //console.log(data.toString());
			body = data.toString();
			json_obj = JSON.parse(body);			 
        });

		request.on('end', function(){
			post_main(json_obj , res);
		 });


    }
if(request.method == 'GET'){

	const responseData = {
		data : "Only Post Method is Allow!!"
	 }

	 
	console.log(responseData);
	jsonContent = JSON.stringify(responseData);
	res.end(jsonContent);
}

};

const server = http.createServer(requestListener);

server.listen(3000,'localhost', function(){
	const resp = nw.CreateNetworkConnection();
	console.log('\n');
	console.log('Connection Respond : ' , resp);
	console.log('\n');

	console.log("Server is Listening at Port 3000!");
});

