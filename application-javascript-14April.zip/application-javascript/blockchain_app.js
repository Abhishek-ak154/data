

var nw = require('./Abstracted_mymodules_location.js');


async function Create_fun(payload){
	
	let res = await nw.CreateAsset(payload);
	console.log("inside create() " , res);
	const ApprovalPerson = approvalRelation[payload.UserName];
	MQTTPublish(ApprovalPerson , res)


}

async function Read_fun()
{
	let res = await nw.GetAllAssets();

	 let PublishPayload = { "TransactionType" : "MyAssets" , "Data" : JSON.parse(res)}
	 console.log("data published : " , PublishPayload);
	 let p =JSON.stringify(PublishPayload, null, 2);
	 await new Promise(resolve => setTimeout(resolve, 3000)); // 3 sec
	 client.publish(topic2, p, { qos: 0, retain: false }, (error) => {
				   
	})
	console.log("data published : " , PublishPayload);

	
}

async function Transfer_fun(payload){

	let res = await nw.TransferAssets(payload);
	console.log("inside Transfer() " , res);
	MQTTPublish(payload.UserName , res)
}



async function Update_fun(payload){

	let res = await nw.UpdateAssets(payload);
	console.log("inside Update() " , res);
	MQTTPublish(payload.UserName , res)
	
}


async function GetHistory_fun(payload){

	let res = await nw.GetHistory(payload.AssetId);

	let PublishPayload = { "TransactionType" : "History" , "Data" : JSON.parse(res)}
    
	let p =JSON.stringify(PublishPayload, null, 2);
	await new Promise(resolve => setTimeout(resolve, 3000)); // 3 sec
	client.publish(topic2, p, { qos: 0, retain: false }, (error) => {
				   
	})
	console.log("data published : " , PublishPayload);
}




 
function SubmitTransaction(id){

	//console.log(pending_txn[id]);

		if(pending_txn[id]){
				var fetchPayload = pending_txn[id];

				if(fetchPayload["TransactionType"] == "Create"){
						Create_fun(fetchPayload);
						console.log("Submit blockchain txn")
				}
				else if(fetchPayload["TransactionType"] == "Transfer"){
					Transfer_fun(fetchPayload);
				}
				else if(fetchPayload["TransactionType"] == "Update"){
					Update_fun(fetchPayload);
				}
				
		}
		else{
			console.log("Data is not available for id " , id);
		}
	
}


async function MQTTPublish(topicName , payload){

	let PublishPayload  =JSON.stringify(payload, null, 2);
	await new Promise(resolve => setTimeout(resolve, 3000)); // 3 sec
	client.publish(topicName, PublishPayload, { qos: 0, retain: false }, (error) => {
				   
	})

	console.log("Data published to",topicName);
}



let obj_copy={"data":"hello"}
let count=1
let client =1
var topic = 'ClientToNetwork';
//var topic = "hlf123";
var topic2 = 'NetworkToClientOrg1';

var pending_txn = {};

var approvalRelation ={ "ak" : "kramis" ,
						"kramis" : "ak",
						"hari" : "biswa",
						"biswa" : "hari"
					   };



async function main(){

		//Making Connection with Network

	const resp = await nw.CreateNetworkConnection();
		console.log('\n');
		console.log('Connection Respond : ' , resp);
		console.log('\n');



		client = await nw.CreateMqttConnection();

		client.on('connect', () => {
			console.log(`Client is Connected to MQTT`)
			client.subscribe([topic ], () => {
			  console.log(`Client has subscribed to the topic : ` , topic)
			})
	
		  })

		  client.on('reconnect', (error) => {
			console.log(`Reconnectin:`, error)
		  })
		  
		  client.on('error', (error) => {
			console.log(`Cannot connect :`, error)
		  })
		  
		  client.on('message', (topic, payload) => {
			console.log('Recieved Message from:', topic, payload.toString())
			


			var obj = JSON.parse(payload);

			
			if(obj.TransactionType == "Approval"){
				
				if(obj.status == "No"){   // if Transaction is rejected by approver
					if(obj.id){			// if txn not available 
						delete pending_txn[obj.id];  // than delete txn
					}
					console.log("Transaction is rejected !!!")
				}

				var id = obj.id;
				SubmitTransaction(id);
			}

			else if(obj.TransactionType == "Create"){
	
				var newid = Math.floor((Math.random() * 10000) + 1);
	
				pending_txn[newid] = obj;
	
				const ApprovalPerson = approvalRelation[obj.UserName];
	
				obj["id"] = newid;
	
				MQTTPublish( ApprovalPerson , obj);
				console.log("Publish Approval request to " , ApprovalPerson);
	
			}
			else if(obj.TransactionType == "Update"){
					Update_fun(obj);

			}
			else if(obj.TransactionType == "Transfer"){
				Transfer_fun(obj);

		}				
		
		})
		  

}

main();

